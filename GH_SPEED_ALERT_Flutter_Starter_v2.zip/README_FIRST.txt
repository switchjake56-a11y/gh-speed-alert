GH SPEED ALERT Flutter starter — version 2.0

IMPORTANT
This is Flutter source code, not an installable APK and not yet a complete Android platform project.

WHAT IS INCLUDED
- Flutter dashboard
- GPS speed stream using Geolocator
- Manual speed-limit test selector
- Overspeed voice warning using Flutter TTS
- Trip-distance estimate
- Camera proximity engine placeholder

WHAT IS NOT YET INCLUDED
- Verified Ghana road speed-limit database / road matching
- Verified TrafficTech camera locations or official data feed
- Background location service
- Complete Android/iOS build folders
- Production testing or signed APK

NEXT STEP
A developer or Flutter-enabled build environment must create the native project scaffolding, add the Android permissions, run flutter pub get, test on a real device, then build and sign the APK.

Do not rely on the manual speed limit as the legal limit for a road. Always follow posted signs.
