import 'dart:async';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:flutter_tts/flutter_tts.dart';

void main() => runApp(const GhSpeedAlertApp());

class GhSpeedAlertApp extends StatelessWidget {
  const GhSpeedAlertApp({super.key});

  @override
  Widget build(BuildContext context) => MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'GH SPEED ALERT',
        theme: ThemeData(
          brightness: Brightness.dark,
          colorScheme: ColorScheme.fromSeed(
            seedColor: const Color(0xFF16C784),
            brightness: Brightness.dark,
          ),
          scaffoldBackgroundColor: const Color(0xFF07152E),
        ),
        home: const SpeedHomePage(),
      );
}

class SpeedHomePage extends StatefulWidget {
  const SpeedHomePage({super.key});

  @override
  State<SpeedHomePage> createState() => _SpeedHomePageState();
}

class _SpeedHomePageState extends State<SpeedHomePage> {
  final FlutterTts _tts = FlutterTts();
  StreamSubscription<Position>? _positionSub;
  double _speedKmh = 0;
  double _distanceKm = 0;
  double _gpsAccuracy = 0;
  int _selectedLimit = 80;
  bool _running = false;
  bool _warningSpoken = false;
  Position? _previous;
  DateTime _lastCameraWarning = DateTime(2000);

  // DEMONSTRATION ONLY: not a verified Ghana/TrafficTech camera database.
  // Add only locations confirmed by an authoritative, maintained source.
  final List<({double lat, double lon, String label})> _verifiedCameras = [];

  @override
  void initState() {
    super.initState();
    _tts.setLanguage('en-GB');
    _tts.setSpeechRate(0.48);
  }

  Future<void> _start() async {
    if (!await Geolocator.isLocationServiceEnabled()) {
      _message('Please turn on your phone location/GPS.');
      await Geolocator.openLocationSettings();
      return;
    }

    var permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
    }
    if (permission == LocationPermission.denied ||
        permission == LocationPermission.deniedForever) {
      _message('Location permission is required for speed monitoring.');
      return;
    }

    setState(() => _running = true);
    const settings = LocationSettings(
      accuracy: LocationAccuracy.bestForNavigation,
      distanceFilter: 3,
    );

    _positionSub = Geolocator.getPositionStream(
      locationSettings: settings,
    ).listen((position) {
      if (position.accuracy > 30) return;

      final rawSpeed = position.speed.isFinite ? position.speed * 3.6 : 0.0;
      final speed = rawSpeed < 3 ? 0.0 : rawSpeed;

      if (_previous != null) {
        final delta = Geolocator.distanceBetween(
          _previous!.latitude,
          _previous!.longitude,
          position.latitude,
          position.longitude,
        );
        // Ignore implausible GPS jumps.
        if (delta >= 2 && delta < 250) _distanceKm += delta / 1000;
      }
      _previous = position;

      setState(() {
        _speedKmh = speed;
        _gpsAccuracy = position.accuracy;
      });
      _checkOverspeed();
      _checkCamera(position);
    }, onError: (_) => _message('GPS update failed. Check location settings.'));
  }

  Future<void> _checkOverspeed() async {
    final over = _speedKmh > _selectedLimit + 3;
    if (over && !_warningSpoken) {
      _warningSpoken = true;
      await _tts.speak('Warning. You may be exceeding the selected speed limit.');
    } else if (!over) {
      _warningSpoken = false;
    }
  }

  Future<void> _checkCamera(Position p) async {
    for (final camera in _verifiedCameras) {
      final metres = Geolocator.distanceBetween(
        p.latitude, p.longitude, camera.lat, camera.lon,
      );
      if (metres <= 500 &&
          DateTime.now().difference(_lastCameraWarning).inSeconds > 60) {
        _lastCameraWarning = DateTime.now();
        await _tts.speak('Caution. ${camera.label} ahead. Drive safely.');
        break;
      }
    }
  }

  Future<void> _stop() async {
    await _positionSub?.cancel();
    _positionSub = null;
    await _tts.stop();
    setState(() {
      _running = false;
      _speedKmh = 0;
      _previous = null;
      _warningSpoken = false;
    });
  }

  void _message(String text) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(text)),
    );
  }

  @override
  void dispose() {
    _positionSub?.cancel();
    _tts.stop();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final over = _speedKmh > _selectedLimit + 3;
    return Scaffold(
      appBar: AppBar(
        title: const Text('GH SPEED ALERT'),
        centerTitle: true,
        backgroundColor: const Color(0xFF020A18),
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            const Text(
              'KNOW YOUR LIMIT. PROTECT YOUR LIFE.',
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.amber, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 22),
            Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: const Color(0xFF020A18),
                border: Border.all(
                  color: over ? Colors.red : const Color(0xFF16C784),
                  width: 9,
                ),
              ),
              child: Column(
                children: [
                  Text(
                    _speedKmh.round().toString(),
                    style: const TextStyle(fontSize: 68, fontWeight: FontWeight.bold),
                  ),
                  const Text('KM/H', style: TextStyle(letterSpacing: 2)),
                  const SizedBox(height: 8),
                  Text(over ? 'SLOW DOWN' : 'CURRENT SPEED',
                      style: TextStyle(color: over ? Colors.redAccent : Colors.white70)),
                ],
              ),
            ),
            const SizedBox(height: 22),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  children: [
                    const Text('SELECTED SPEED LIMIT'),
                    DropdownButton<int>(
                      value: _selectedLimit,
                      items: [30, 40, 50, 60, 80, 100, 120]
                          .map((v) => DropdownMenuItem(value: v, child: Text('$v km/h')))
                          .toList(),
                      onChanged: _running ? null : (v) => setState(() => _selectedLimit = v!),
                    ),
                    const Text(
                      'This is a manual test setting, not automatic road detection.',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: Colors.amber, fontSize: 12),
                    ),
                  ],
                ),
              ),
            ),
            Row(
              children: [
                Expanded(child: _stat('TRIP DISTANCE', '${_distanceKm.toStringAsFixed(2)} km')),
                Expanded(child: _stat('GPS ACCURACY', _running ? '±${_gpsAccuracy.round()} m' : 'OFF')),
              ],
            ),
            const SizedBox(height: 18),
            if (over)
              const Card(
                color: Colors.red,
                child: Padding(
                  padding: EdgeInsets.all(14),
                  child: Text('OVERSPEED WARNING', textAlign: TextAlign.center,
                      style: TextStyle(fontWeight: FontWeight.bold)),
                ),
              ),
            const SizedBox(height: 18),
            SizedBox(
              height: 56,
              child: FilledButton(
                style: FilledButton.styleFrom(
                  backgroundColor: _running ? Colors.red : const Color(0xFF16A765),
                ),
                onPressed: _running ? _stop : _start,
                child: Text(_running ? 'STOP MONITORING' : 'START MONITORING'),
              ),
            ),
            const SizedBox(height: 14),
            const Text(
              'Safety note: GPS speed can be inaccurate. Always obey posted road signs. '
              'Camera alerts are inactive until verified camera data is added. '
              'Do not operate the phone while driving.',
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.white60, fontSize: 12),
            ),
          ],
        ),
      ),
    );
  }

  Widget _stat(String title, String value) => Card(
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(children: [
            Text(title, style: const TextStyle(color: Colors.white60, fontSize: 11)),
            const SizedBox(height: 6),
            Text(value, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          ]),
        ),
      );
}
